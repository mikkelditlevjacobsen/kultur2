var db_connect = require("../config/config").connect();
module.exports = function(app) {
  app.get("/", function(req, res) {
    res.render("pages/index", {
      side: "index"
    });
  });
  app.get("/alle", function(req, res) {
    res.render("pages/index", {
      side: "alle"
    });
  });
  app.get("/admin", function(req, res) {
    res.render("pages/index", {
      side: "admin"
    });
  });
  app.get("/news", function(req, res) {
    db_connect.query(
      "SELECT type, artist, DATE_FORMAT(date, '%m/%d/%Y %H:%i') AS 'date', price, _added FROM news WHERE _added >= ( CURDATE() - INTERVAL 8 DAY ) ORDER BY _added DESC",
      (error, rows) => {
        res.json(rows);
      }
    );
  });
  app.get("/allnews", function(req, res) {
    db_connect.query(
      "SELECT id, type, artist, DATE_FORMAT(date, '%m/%d/%Y %H:%i') AS 'date', price, _added FROM news ORDER BY _added DESC",
      (error, rows) => {
        res.json(rows);
      }
    );
  });
  app.get("/admin/:id", function(req, res) {
    res.render("pages/index", {
      side: "edit",
      id: req.params.id
    });
  });
  app.get("/sog/:soog", function(req, res) {
    db_connect.query(
      `SELECT type, artist, DATE_FORMAT(date, '%m/%d/%Y %H:%i') AS 'date', price, _added FROM news WHERE artist LIKE '%${req.params.soog}%' ORDER BY _added DESC`,
      (error, rows) => {
        res.json(rows);
      }
    );
  });
  app.get("/allnews/:kategori", function(req, res) {
    db_connect.query(
      "SELECT type, artist, DATE_FORMAT(date, '%m/%d/%Y %H:%i') AS 'date', price, _added FROM news WHERE type = ? ORDER BY _added DESC",
      [req.params.kategori],
      (error, rows) => {
        res.json(rows);
      }
    );
  });
  app.get("/all/:id", function(req, res) {
    db_connect.query(
      `SELECT id, type, artist, DATE_FORMAT(date, '%m/%d/%Y %H:%i') AS 'date', price, _added FROM news WHERE id = ${req.params.id}`,
      (error, rows) => {
        res.json(rows);
      }
    );
  });
  app.get("/kategori", function(req, res) {
    db_connect.query("SELECT * FROM billede_kategori", (error, rows) => {
      res.json(rows);
    });
  });
};