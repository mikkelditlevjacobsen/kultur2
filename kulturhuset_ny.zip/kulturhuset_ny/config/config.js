var db_connect = require("mysql");
function connect() {
  return db_connect.createConnection({
    host: "localhost",
    user: "root",
    password: "root",
    database: "kultur",
    port: 8889
  });
}
module.exports = {
  connect
};